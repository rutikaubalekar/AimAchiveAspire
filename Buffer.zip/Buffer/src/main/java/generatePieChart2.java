

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class generatePieChart2
 */
@WebServlet("/generatePieChart2")
public class generatePieChart2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  PrintWriter out = response.getWriter();
	        String sessiontype=request.getParameter("sessiontype");
	        String session_name=request.getParameter("session_name");

		  String year=request.getParameter("year");
	        int[] departmentCounts1 = new int[2];
	        int totalreg=0;
	        try {
	            Class.forName("com.mysql.jdbc.Driver");
	            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root","MansiItaly@123" );
	           
	            PreparedStatement ps=con.prepareStatement("select COUNT(DISTINCT r.regid) AS totalreg, COUNT(DISTINCT CASE WHEN a.status = 'P' THEN r.regid END) AS presentcount FROM Session s JOIN Registration2 r ON s.session_id = r.session_id JOIN Attendance a ON r.regid = a.regid AND s.session_id = a.session_id where s.sessiontype =? and s.session_name = ? AND s.year = ? GROUP BY s.session_id;");
	           
	            ps.setString(1 , sessiontype);
	            ps.setString(2, session_name);
	            ps.setString(3, year);

	            ResultSet rs=ps.executeQuery();	

	            while (rs.next()) {
	                totalreg=rs.getInt("totalreg");
	                int presentcount=rs.getInt("presentcount");
	                
	                        departmentCounts1[0] = totalreg;
	                       
	                    
	                        departmentCounts1[1] = presentcount;
	                      
	                
	            }
	            request.setAttribute("departmentCounts1", departmentCounts1);
	            RequestDispatcher dispatcher = request.getRequestDispatcher("piechart2.jsp");
            dispatcher.forward(request, response);            
	           
	        } catch (SQLException e) {
	            throw new ServletException("SQL error", e);
	        } catch (ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	 
	        
//	        out.println("<html>");
//		    out.println("<head>");
//		    out.println("<title>Data for branch </title>");
//		      out.println("</head>");
//	
//		      out.println("<body>");
//	
//		      out.println("<td>" + departmentCounts1[0] +departmentCounts1[1]+ "</td>");
//		      out.println("<td>" + year+""+sessiontype+""+session_name +departmentCounts1[1]+totalreg+ "</td>");
//	
//		      out.println("</body>");
//			    out.println("</html>");

	    }
	

	}


