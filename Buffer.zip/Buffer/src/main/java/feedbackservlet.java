

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class feedbackservlet
 */
@WebServlet("/feedbackservlet")
public class feedbackservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  String name = request.getParameter("name");
	        String email = request.getParameter("email");
	        String year = request.getParameter("year");
	        String branch = request.getParameter("branch");
	        String session_name = request.getParameter("session");
	        String feedback = request.getParameter("feedback");

	        PrintWriter out = response.getWriter();

	        // database connection credentials
	        String url = "jdbc:mysql://localhost:3306/dbms";
	        String username = "root";
	        String password = "MansiItaly@123";

	        try {
	            // create database connection
	            Connection conn = DriverManager.getConnection(url, username, password);

	            // prepare SQL statement
	            String sql = "INSERT INTO Feedback (name, email, year, branch, session,feedback) VALUES (?, ?, ?, ?, ?, ?)";
	            PreparedStatement statement = conn.prepareStatement(sql);
	            statement.setString(1, name);
	            statement.setString(2, email);
	            statement.setString(3, year);
	            statement.setString(4, branch);
	            statement.setString(5, session_name);
	            statement.setString(6, feedback);

	            // execute SQL statement
	            statement.executeUpdate();

	            // update registration date
	           
	            out.print(branch);
	            // close database connection
	            RequestDispatcher rd = request.getRequestDispatcher("regsub.jsp");
	            rd.forward(request, response);
	            conn.close();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	}

}
