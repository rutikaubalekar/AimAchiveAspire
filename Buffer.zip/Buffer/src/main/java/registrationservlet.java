

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/registrationservlet")
public class registrationservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String email = request.getParameter("email");
	        String password = request.getParameter("password");
	        // database connection credentials
	       
			RequestDispatcher rd=null;

	        try {
	            // create database connection
	            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root", "MansiItaly@123");

	            // prepare SQL statement
	            String sql = "INSERT INTO Login (email, password) VALUES (?, ?)";
	            PreparedStatement statement = conn.prepareStatement(sql);
	            statement.setString(1, email);
	            statement.setString(2, password);
	            

	            // execute SQL statement
	            statement.executeUpdate();
	            boolean registrationSuccessful = true;
	            if (registrationSuccessful) {
	                // Add a success message to session
	                HttpSession session = request.getSession();
	                session.setAttribute("message", "Registration successful! Please login.");

	                // Redirect to login.jsp
	                response.sendRedirect("index3.jsp");
	            }
	            // close database connection
	            conn.close();

	           
	         
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	          

	}

}
