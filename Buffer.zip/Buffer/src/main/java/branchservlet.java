
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.x.protobuf.MysqlxCrud.Column;

@WebServlet("/branchservlet")
public class branchservlet extends HttpServlet {

private static final long serialVersionUID = 1L;

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	 response.setContentType("text/html");
	    PrintWriter out = response.getWriter();
	    String branch = request.getParameter("branch");
	    String[] sessionIds = new String[50];
	    String[] sessionTypes = new String[50];
	    String[] sname = new String[50];

	    String[] dates = new String[50];
	    String[] regid = new String[50];
	    String[] rollno = new String[50];
	    String[] name = new String[50];

	    String[] email= new String[50];
	    String[] phone = new String[50];
	    String[] year = new String[50];
	    String[] batch = new String[50];
	    String[] attendence = new String[50];
	    int i = 0;

	    try {
	      // Get a Connection object using the DriverManager
	      Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root", "MansiItaly@123");

	      // Create a PreparedStatement object
	      PreparedStatement pstmt = con.prepareStatement(" SELECT DISTINCT s.session_id, s.sessiontype, s.session_name, s.date, r.regid, r.studentroll, r.name, r.email, r.phno, r.year, r.batch, a.status FROM Session s, Registration2 r, Attendance a WHERE s.session_id=r.session_id AND s.session_id=a.session_id and r.regid=a.regid AND r.branch=? order by s.date asc");

	      // Set the parameter value
	      pstmt.setString(1, branch);

	      // Execute the query
	      ResultSet rs = pstmt.executeQuery();

	      // Loop through the result set and store data in arrays
	      while (rs.next()) {
	        sessionIds[i] = rs.getString("session_id");
	        sessionTypes[i] = rs.getString("sessiontype");
	        sname[i] = rs.getString("session_name");

	        dates[i] = rs.getString("date");
	        regid[i] = rs.getString("regid");
	        rollno[i] = rs.getString("studentroll");
	        name[i] = rs.getString("name");
	        email[i] = rs.getString("email");
	        phone[i] = rs.getString("phno");
	        year[i] = rs.getString("year");
	        batch[i] = rs.getString("batch");
	       attendence[i] = rs.getString("status");
	        i++;
			System.out.println("mansi");

	      }

	      // Clean up resources
	      rs.close();
	      pstmt.close();
	      con.close();
	    } catch (SQLException e) {
	      e.printStackTrace();
	    }

	    // Generate the HTML response using the data from the arrays
	   
	   
	    out.println("<html>");
	    out.println("<head>");
	    out.println("<title>Data for branch " + branch + "</title>");
	    out.println("<style>");
	    out.println("table, th, td { border: 1px solid black; border-collapse: collapse; padding: 5px; }");
	    out.println("</style>");
	    out.println("</head>");
	    out.println("<body>");
	    
	    out.println("<h1 style='color:white; font-weight:bold'>Data of branch:" + branch + "</h1>");
	    out.println("<table>"); 
	    out.println("<tr><th>Session Id</th><th>Session Type</th><th>Session Name</th><th>Session Date</th><th>Regitration ID</th><th>Roll Number</th><th>Name</th><th>Email</th><th>Phone Number</th><th>Year</th><th>Batch</th><th>Attendence</th></tr>");
	    for (int j = 0; j < i; j++) {
	      out.println("<tr>");
	      out.println("<td>" + sessionIds[j] + "</td>");
	      out.println("<td>" + sessionTypes[j] + "</td>");
	      out.println("<td>" + sname[j] + "</td>");

	      out.println("<td>" + dates[j] + "</td>");
	      out.println("<td>" + regid[j] + "</td>");
	      out.println("<td>" + rollno[j] + "</td>");
	      out.println("<td>" + name[j] + "</td>");
	      out.println("<td>" + email[j] + "</td>");
	      out.println("<td>" + phone[j] + "</td>");
	      out.println("<td>" + year[j] + "</td>");
	      out.println("<td>" + batch[j] + "</td>");
	      out.println("<td>" + attendence[j] + "</td>");

	      out.println("</tr>");
	    }
	    out.println("</table>");
	    out.println("</body>");
	    out.println("</html>");
	    i=0;
	    // Render the form with a button and a hidden drop-down menu
	    
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
        out.println("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css\">");
        out.println("<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js\"></script>");
        out.println("<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js\"></script>");
        out.println("<style>");
        out.println(".dropdown-submenu {");
        out.println("position: relative;");
        out.println("}");
        out.println(".dropdown-submenu .dropdown-menu {");
        out.println("top: 0;");
        out.println("left: 100%;");
        out.println("margin-top: -1px;");
        out.println("}");
        out.println("  body {");
        out.println("    padding: 0px;");
        out.println("    margin: 0;");
        out.println("    min-height: 100vh;");
        out.println("    background: url('background_cleanup.jpg')no-repeat;");
        out.println("    background-position: center;");
        out.println("    background-size: cover;");
        out.println("    background-color: transparent;");
        out.println("    backdrop-filter: blur(15px);");
        out.println("  }");
        out.println("  table {");
        out.println("    width: 100%;");
        out.println("    max-width: 100%;");
        out.println("    font-size: medium;");
        out.println("    font-family:sans-serif");

        out.println("    font-weight: 100;");
        out.println("  }");
        out.println("  table th, table td {");
        out.println("    border: 1px solid white;");
        out.println("    padding: 10px;");
        out.println("    color: white;");
        out.println("  }");
        out.println("  table th {");
        out.println("    font-weight: bold;");
        out.println("    color: rgb(197, 157, 14);");
        out.println("  }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class=\"container\">");
       
        out.println("<div class=\"dropdown\">");
        out.println("<button class=\"btn btn-default dropdown-toggle\" type=\"button\" data-toggle=\"dropdown\">FILTER");
        out.println("<span class=\"caret\"></span></button>");
        out.println("<ul class=\"dropdown-menu\">");
        out.println("<li class=\"dropdown-submenu\">");
        out.println("<a class=\"test\" tabindex=\"-1\" href=\"#\">YEAR<span class=\"caret\"></span></a>");
        out.println("<ul class=\"dropdown-menu\">");
        String url = "jdbc:mysql://localhost:3306/dbms";
        String user = "root";
        String password = "MansiItaly@123";
        Connection conn = null;
        Statement stmt = null;
	    String branch1 = request.getParameter("branch");

        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(url, user, password);
            stmt = conn.createStatement();
            String sql = "SELECT DISTINCT year FROM Registration2";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                out.println("<li><a tabindex=\"-1\" href=\"#\">" + rs.getString("year") + "</a></li>");
            }
            sql = " SELECT DISTINCT s.session_id, s.sessiontype, s.session_name, s.date, r.regid, r.studentroll, r.name, r.email, r.phno, r.year, r.batch, a.status FROM Session s, Registration2 r, Attendance a WHERE s.session_id=r.session_id AND s.session_id=a.session_id AND r.branch?=? and r.year=? ";
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                out.println("<li><a tabindex=\"-1\" href=\"#\">" + rs.getString("year") + "</a></li>");
            }
            
            
        } catch (ClassNotFoundException | SQLException ex) {
            out.println(ex.getMessage());
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                out.print(ex.getMessage ());}
        }
        out.println("</ul>");
        out.println("</li>");
        
        out.println("<li class=\"dropdown-submenu\">");
        out.println("<a class=\"test\" tabindex=\"-1\" href=\"#\">BATCH<span class=\"caret\"></span></a>");
        out.println("<ul class=\"dropdown-menu\">");
        // connect to your database
        url = "jdbc:mysql://localhost:3306/dbms";
        user = "root";
        password= "MansiItaly@123";
        conn = null;
        stmt = null;
        try {
        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection(url, user, password);
        stmt = conn.createStatement();
        String sql = "SELECT DISTINCT batch FROM Registration2";
        ResultSet rs = stmt.executeQuery(sql);
        while (rs.next()) {
        out.println("<li><a tabindex=\"-1\" href=\"#\">" + rs.getString("batch") + "</a></li>");
        }
        } catch (ClassNotFoundException | SQLException ex) {
        out.println(ex.getMessage());
        } finally {
        try {
        if (stmt != null) {
        stmt.close();
        }
        if (conn != null) {
        conn.close();
        }
        } catch (SQLException ex) {
        out.println(ex.getMessage());
        }
        }
        out.println("</ul>");
        out.println("</li>");

        out.println("<li class=\"dropdown-submenu\">");
        out.println("<a class=\"test\" tabindex=\"-1\" href=\"#\">ATTENDANCE<span class=\"caret\"></span></a>");
        out.println("<ul class=\"dropdown-menu\">");
        // connect to your database
        url = "jdbc:mysql://localhost:3306/dbms";
        user = "root";
        password = "MansiItaly@123";
        conn = null;
        stmt = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(url, user, password);
            stmt = conn.createStatement();
            String sql = "SELECT DISTINCT status FROM Attendance";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                out.println("<li><a tabindex=\"-1\" href=\"#\">" + rs.getString("status") + "</a></li>");
            }
        } catch (ClassNotFoundException | SQLException ex) {
            out.println(ex.getMessage());
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                out.println(ex.getMessage());
            }
        }
        out.println("</ul>");
        out.println("</li>");

        out.println("</ul>");
        out.println("</div>");
        out.println("</div>");
        out.println("<script>");
        out.println("$(document).ready(function(){");
        out.println("$('.dropdown-submenu a.test').on(\"click\", function(e){");
        out.println("$(this).next('ul').toggle();");
        out.println("e.stopPropagation();");
        out.println("e.preventDefault();");
        out.println("});");
        out.println("});");
        out.println("</script>");
        out.println("</body>");
        out.println("</html>");

	    
	    
//	    response.setContentType("text/html");
//	    response.getWriter().println("<html><body>");
//	    response.getWriter().println("<h1>Sort By</h1>");
//	    response.getWriter().println("<select id='sortOptions' onchange='handleSortBy()'>");
//
//	    response.getWriter().println("<button id='sortBtn' onclick='showOptions()'>SORT BY</button>");
//	    response.getWriter().println("<option value='sortby'>FILTER</option>");
//	   
//	    response.getWriter().println("<option value='year'>YEAR</option>");
//	    
//	    response.getWriter().println("<option value='branch'>BRANCH</option>");
//	    response.getWriter().println("<option value='batch'>BATCH</option>");
//	    response.getWriter().println("<option value='attendance'>ATTENDANCE</option>");
//
//	    response.getWriter().println("</select>");
//	    response.getWriter().println("<script>");
//	    response.getWriter().println("function showOptions() {");
//	    response.getWriter().println("var dropdown = document.getElementById('sortOptions');");
//	    response.getWriter().println("dropdown.style.display = (dropdown.style.display === 'none') ? 'block' : 'none';");
//	    response.getWriter().println("}");
//	    response.getWriter().println("function handleSortBy() {");
//	    response.getWriter().println("var selectedOption = document.getElementById('sortOptions').value;");
//	    response.getWriter().println("if (selectedOption === 'year') {");
//	    response.getWriter().println("alert('Sorting by Year...');");
//	    response.getWriter().println("} else if (selectedOption === 'branch') {");
//	    response.getWriter().println("alert('Sorting by Branch...');");
//	    response.getWriter().println("}");
//	    response.getWriter().println("}");
//	    response.getWriter().println("</script>");
//	    response.getWriter().println("</body></html>");


}
}

