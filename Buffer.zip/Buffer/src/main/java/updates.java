import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class updates
 */
@WebServlet("/updates")
public class updates extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setContentType("text/html");
	        PrintWriter out = response.getWriter();

	        // Get the attendance status and registration id from the request parameter
	        String status = request.getParameter("status");
	        String regid = request.getParameter("regid");

	        try {
	            // Get a connection to the database
	            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root", "MansiItaly@123");

	            // Prepare a statement to update the attendance status
	            PreparedStatement pstmt = con.prepareStatement("UPDATE Attendance SET status=? WHERE regid=?");
	            pstmt.setString(1, status);
	            pstmt.setString(2, regid);

	            // Execute the query
	            int rowsUpdated = pstmt.executeUpdate();

	            // Check if any rows were updated
	            if(rowsUpdated > 0) {
	                out.println("Attendance updated successfully!!!");
	            } else {
	                out.println("No record found for the specified registration id.");
	            }

	            // Clean up resources
	            pstmt.close();
	            con.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	}
}
