
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/dbmservlet")
public class dbmservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;accept-charset=ISO-8859-1");

		try{
			PrintWriter out=response.getWriter();
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root","MansiItaly@123" );
			String n=request.getParameter("email");
			String p=request.getParameter("password");
			RequestDispatcher rd=null;
			
			PreparedStatement ps=con.prepareStatement("select email from Login where email=? and password=?" );
			ps.setString(1, n);
			ps.setString(2, p);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
			    String email = rs.getString("email");
			    request.setAttribute("email", email);
			    if(n.equals("mansi@gmail.com") && p.equals("mansi123")) {
			        rd=request.getRequestDispatcher("vum.jsp");
			        rd.forward(request, response);
			    } else {
			        rd=request.getRequestDispatcher("student.jsp");
			        rd.forward(request, response);
			    }
			} else {
			    rd = request.getRequestDispatcher("index1.jsp");
			    rd.forward(request, response);
			}
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}





