

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;	
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class displays
 */
@WebServlet("/displays")
public class displays extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 PrintWriter out = response.getWriter();
	        

	        // Get the session type from the request parameter

	        // Define arrays to store the data from the database
	        String[] sessionIds = new String[50];
	        String[] sessionTypes = new String[50];
	        String[] venue = new String[50];
	        String[] dates = new String[50];
	        String[] time = new String[50];
	        String[] year = new String[50];
	        String[] name = new String[50];
	        String[] vIds = new String[50];
		    String[] role = new String[50];
		    String[] vname = new String[50];
		    String[] branch = new String[50];
		    String[] vemail= new String[50];
		    String[] vphone = new String[50];
		    String[] lIds = new String[50];
		    String[] lname = new String[50];
		    String[] lemail= new String[50];
		    String[] lphone = new String[50];
		   
	        int i = 0;

	        try {
	            // Get a connection to the database
	            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root", "MansiItaly@123");

	            // Prepare a statement to query the database
	            PreparedStatement pstmt = con.prepareStatement("select s.session_id,s.sessiontype,s.venue,s.date,s.time,s.year,s.session_name,v.volunteer_id,v.Role,v.Vname,v.Branch,v.vemail,v.vphoneno,l.lecturer_id,l.Name,l.Email,l.Phone_Number\r\n"
	            		+ "    ->  from Session s,Lecturer l,Volunteer v\r\n"
	            		+ "    -> where s.session_id=l.session_id and s.session_id=v.session_id;");

	            // Set the parameter value
	          

	            // Execute the query
	            ResultSet rs = pstmt.executeQuery();

	            // Loop through the result set and store data in arrays
	            while (rs.next()) {
	                sessionIds[i] = rs.getString("session_id");
	                sessionTypes[i] = rs.getString("sessiontype");
	                venue[i] = rs.getString("venue");
	                dates[i] = rs.getString("date");
	                time[i] = rs.getString("time");
	                year[i] = rs.getString("year");
	                name[i] = rs.getString("session_name");
	                vIds[i] = rs.getString("volunteer_id");
	                role[i] = rs.getString("Role");
	                vname[i] = rs.getString("Vname");
	                branch[i] = rs.getString("Branch");
	                vemail[i] = rs.getString("vemail");
	                vphone[i] = rs.getString("vphoneno");
	                lIds[i] = rs.getString("lecturer_id");
	                lname[i] = rs.getString("Name");
	                lemail[i] = rs.getString("Email");
	                lphone[i] = rs.getString("Phone_Number");

	                i++;
	            }


	            // Clean up resources
	            rs.close();
	            pstmt.close();
	            con.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
		    // Generate the HTML response using the data from the arrays
		    out.println("<html>");
		    out.println("<head>");
		    out.println("<title>NEW SESSION ADDED SUCCESSFULLY!!! "  + "</title>");
		    out.println("<style>");
		    out.println("table, th, td { border: 1px solid black; border-collapse: collapse; padding: 5px; }");
		    out.println("</style>");
		    out.println("</head>");
		    out.println("<body>");
		    out.println("<h1>Data of Sessions  " +  "</h1>");
		    out.println("<table>");
		    out.println("<tr><th>Session Id</th><th>Session Type</th><th>Session Name</th><th>Session Venue</th><th>Session Date</th><th>Time</th><th>Year</th><th>Lecturer ID</th><th>Lecturer Name</th><th>Lecturer Email</th><th>Lecturer Phone Number</th><th>Volunteer ID</th><th>Role of Volunteer</th><th>Volunteer Name</th><th>Branch</th><th>Volunteer Email</th><th>Volunteer Phone Number</th></tr>");
		    for (int j = 0; j < i; j++) {
		      out.println("<tr>");
		      out.println("<td>" + sessionIds[j] + "</td>");
		      out.println("<td>" + sessionTypes[j] + "</td>");
		      out.println("<td>" + name[j] + "</td>");
		      out.println("<td>" + venue[j] + "</td>");
		      out.println("<td>" + dates[j] + "</td>");
		      out.println("<td>" + time[j] + "</td>");
		      out.println("<td>" + year[j] + "</td>");
		      out.println("<td>" + name[j] + "</td>");
		      out.println("<td>" + lIds[j] + "</td>");
		      out.println("<td>" + lname[j] + "</td>");
		      out.println("<td>" + lemail[j] + "</td>");
		      out.println("<td>" + lphone[j] + "</td>");
		      out.println("<td>" + vIds[j] + "</td>");
		      out.println("<td>" + role[j] + "</td>");
		      out.println("<td>" + vname[j] + "</td>");
		      out.println("<td>" + branch[j] + "</td>");
		      out.println("<td>" + vemail[j] + "</td>");
		      out.println("<td>" + vphone[j] + "</td>");

		    

		      out.println("</tr>");
		    }
		    out.println("</table>");
		    out.println("</body>");
		    out.println("</html>");
	}
	
	}


