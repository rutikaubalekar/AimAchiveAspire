

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class inserts
 */
@WebServlet("/inserts")
public class inserts extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        String stype = request.getParameter("sessiontype");
	        String sname = request.getParameter("session_name");
	        String venue = request.getParameter("venue");
	        String date = request.getParameter("date");
	        String time = request.getParameter("time");
	        String year = request.getParameter("year");
	        
	        String lname = request.getParameter("Name");
	        String lemail = request.getParameter("Email");
	        String lphno = request.getParameter("Phone_Number");
	        String sessionid = request.getParameter("NULL");

	        String vname = request.getParameter("Vname");
	        String branch = request.getParameter("Branch");
	        String vemail = request.getParameter("vemail");
	        String vphno = request.getParameter("vphoneno");
	        String role = request.getParameter("Role");

	        
	        PrintWriter out = response.getWriter();

	        // database connection credentials
	        String url = "jdbc:mysql://localhost:3306/dbms";
	        String username = "root";
	        String password = "MansiItaly@123";

	        try {
	            // create database connection
	            Connection conn = DriverManager.getConnection(url, username, password);

	            // prepare SQL statement
	            String sql = "INSERT INTO Session ( sessiontype, session_name, venue,date,time,year) VALUES ( ?, ?, ?, ?, ?, ?)";
	            PreparedStatement statement = conn.prepareStatement(sql);
	            statement.setString(1, stype);
	            statement.setString(2, sname);
	            statement.setString(3, venue);
	            statement.setString(4, date);
	            statement.setString(5, time);
	            statement.setString(6, year);

	            // execute SQL statement
	            statement.executeUpdate();
	            
	            String sessionIDQuery = "SELECT session_id FROM Session WHERE sessiontype=?";
	            PreparedStatement sessionIDStatement = conn.prepareStatement(sessionIDQuery);
	            sessionIDStatement.setString(1, stype);
	            ResultSet sessionIDResult = sessionIDStatement.executeQuery();
	            String sessionID = null;
	            if (sessionIDResult.next()) {
	                sessionID = sessionIDResult.getString("session_id");
	            }

	            // prepare SQL statement for Lecturer table
	            sql = "INSERT INTO Lecturer (Name, Email, Phone_Number, session_id) VALUES ( ?, ?, ?, ?)";
	          statement = conn.prepareStatement(sql);
	            statement.setString(1, lname);
	            statement.setString(2, lemail);
	            statement.setString(3, lphno);
	            statement.setString(4, sessionID);
	            statement.executeUpdate();


	            sql = "INSERT INTO Volunteer (Vname ,Branch, vemail,vphoneno,Role,session_id) VALUES (  ?, ?, ?,?,?,?)";
		        statement = conn.prepareStatement(sql);
		            statement.setString(1, vname);
		            statement.setString(2, branch);
		            statement.setString(3, vemail);
		            statement.setString(4, vphno);
		            statement.setString(5, role);
		            statement.setString(6, sessionID);


		            // execute SQL statement
		            statement.executeUpdate();
		            
	            RequestDispatcher dispatcher = request.getRequestDispatcher("displays");
	            dispatcher.forward(request, response);    
	            conn.close();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        
//	        out.println("<html>");
//		    out.println("<head>");
//		    out.println("<title>Data for branch </title>");
//		      out.println("</head>");
//
//		      out.println("<body>");
//
//		      out.println("<td>" + session_name +sessiontype+ "</td>");
//		      out.println("<td>" + year+""+sessiontype+""+session_name+name+rollno+ "</td>");
//
//		      out.println("</body>");
//			    out.println("</html>");
	}

}
