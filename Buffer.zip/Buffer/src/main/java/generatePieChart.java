import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/generatePieChart")
public class generatePieChart extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        String year=request.getParameter("year");
        String sessiontype=request.getParameter("sessiontype");
        String session_name=request.getParameter("session_name");
        int[] departmentCounts = new int[5];
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root","MansiItaly@123" );
           
            PreparedStatement ps=con.prepareStatement("SELECT COUNT(distinct r.regid) AS count, r.branch as branch FROM Session s, Registration2 r, Attendance a WHERE s.session_id=r.session_id AND r.session_id=a.session_id AND a.status='P' AND s.year=? AND s.sessiontype=? AND s.session_name=? GROUP BY r.branch;" );
            ps.setString(1, year);
            ps.setString(2, sessiontype);
            ps.setString(3, session_name);

            ResultSet rs=ps.executeQuery();

            while (rs.next()) {
                String branch=rs.getString("branch");
                int count=rs.getInt("count");
                switch (branch) {
                    case "IT":
                        departmentCounts[0] = count;
                        break;
                    case "COMP":
                        departmentCounts[1] = count;
                        break;
                    case "MECH":
                        departmentCounts[2] = count;
                        break;
                    case "INSTRU":
                        departmentCounts[3] = count;
                        break;
                    case "ENTC":
                        departmentCounts[4] = count;
                        break;
                }
            }
            request.setAttribute("departmentCounts", departmentCounts);
            
            RequestDispatcher dispatcher = request.getRequestDispatcher("piechart.jsp");
            dispatcher.forward(request, response);            
           
        } catch (SQLException e) {
            throw new ServletException("SQL error", e);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
 
//        
//        out.println("<html>");
//	    out.println("<head>");
//	    out.println("<title>Data for branch </title>");
//	      out.println("</head>");
//
//	      out.println("<body>");
//
//	      out.println("<td>" + departmentCounts[0] +departmentCounts[1]+ "</td>");
//	      out.println("<td>" + year+""+sessiontype+""+session_name +departmentCounts[1]+ "</td>");
//
//	      out.println("</body>");
//		    out.println("</html>");

    }
}
