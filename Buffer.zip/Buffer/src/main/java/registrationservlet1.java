import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/registrationservlet1")
public class registrationservlet1 extends HttpServlet {
  
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // retrieve form data
        String name = request.getParameter("name");
        String rollno = request.getParameter("rollno");
        String email = request.getParameter("email");
        String phno = request.getParameter("Phone_Number");

        String year = request.getParameter("year");
        String branch = request.getParameter("branch");
        String batch = request.getParameter("batch");

        String session_name = request.getParameter("session_name");
        String sessiontype = request.getParameter("sessiontype");
    

        PrintWriter out = response.getWriter();

        // database connection credentials
        String url = "jdbc:mysql://localhost:3306/dbms";
        String username = "root";
        String password = "MansiItaly@123";

        try {
            // create database connection
            Connection conn = DriverManager.getConnection(url, username, password);


            
            String sessionIDQuery = "select session_id from Session where session_name=?";
            PreparedStatement sessionIDStatement = conn.prepareStatement(sessionIDQuery);
            sessionIDStatement.setString(1, session_name);
            ResultSet sessionIDResult = sessionIDStatement.executeQuery();
            String sessionID = null;
            if (sessionIDResult.next()) {
                sessionID = sessionIDResult.getString("session_id");
                out.print(sessionID);
            }

            String count = "SELECT COUNT(*) + 1 as count FROM Registration2 WHERE session_id = ?";
            PreparedStatement sessionIDStatement1 = conn.prepareStatement(count);
            sessionIDStatement1.setString(1, sessionID);
            ResultSet sessionIDResult1 = sessionIDStatement1.executeQuery();
            String count1 = null;
            if (sessionIDResult1.next()) {
                count1 = sessionIDResult1.getString("count");
                out.print(count1);
            }

            String sql1 = "INSERT INTO Registration2( studentroll,name,email,phno,  year,branch,batch,  session_name, sessiontype, regid, session_id) VALUES (?, ?, ?, ?, ?, ?,?,?,?, CONCAT('r', ?, 's', ?), ?)";
            PreparedStatement statement1 = conn.prepareStatement(sql1, Statement.RETURN_GENERATED_KEYS);

            statement1.setString(2, name);
            statement1.setString(1, rollno);
            statement1.setString(3, email);
            statement1.setString(4, phno);
            statement1.setString(7, batch);
            statement1.setString(6, branch);
            statement1.setString(5, year);
            statement1.setString(8, session_name);
            statement1.setString(9, sessiontype);
            statement1.setString(10, count1);
            statement1.setString(11, sessionID);
            statement1.setString(12, sessionID);

            // execute SQL statement
            int rowsInserted = statement1.executeUpdate();
            // retrieve the generated keys
String regid1 = "select regid from Registration2 where phno=?";
PreparedStatement sessionIDStatement3 = conn.prepareStatement(regid1);
sessionIDStatement3.setString(1,phno);
ResultSet sessionIDResult3 = sessionIDStatement3.executeQuery();
String regid=null;
if (sessionIDResult3.next()) {
   regid = sessionIDResult3.getString("regid");
    out.print(regid);
}



            String sql2 = "UPDATE Registration2 SET regdate = CURDATE() WHERE studentroll = ?";
            PreparedStatement statement2 = conn.prepareStatement(sql2);
            statement2.setString(1, rollno);
            statement2.executeUpdate();
          

            String sql3=" insert into Attendance (regid,session_id)values(?,?)";
            // close database connection
            PreparedStatement statement3 = conn.prepareStatement(sql3);
            statement3.setString(1, regid);
            statement3.setString(2, sessionID);

            statement3.executeUpdate();
          
            conn.close();
            
            // redirect to success page
//            RequestDispatcher dispatcher = request.getRequestDispatcher("regsub.jsp");
//            dispatcher.forward(request, response);

        } catch (Exception e) {
            out.print("Error: " + e.getMessage());
        }
    

        
//        out.println("<html>");
//	    out.println("<head>");
//	    out.println("<title>Data for branch </title>");
//	      out.println("</head>");
//
//	      out.println("<body>");
//
//	      out.println("<td>" + session_name +sessiontype+ "</td>");
//	      out.println("<td>" + year+""+sessiontype+""+session_name+name+rollno+ regdate+"</td>");
//
//	      out.println("</body>");
//		    out.println("</html>");

    }}