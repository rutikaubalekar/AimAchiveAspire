import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/attendanceservlet")
public class attendanceservlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String session_name = request.getParameter("session_name");

        // Define arrays to store the data from the database
        String[] rollno = new String[50];
        String[] regid = new String[50];
        String[] name = new String[50];
        String[] email = new String[50];
        String[] phno = new String[50];
        String[] year = new String[50];
        String[] branch = new String[50];

        int i = 0;

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root",
                    "MansiItaly@123");
            PreparedStatement pstmt = con.prepareStatement(
                    "SELECT DISTINCT r.studentroll, r.regid, r.name, r.email, r.phno, r.year, r.branch FROM Registration2 r, Attendance a, Session s WHERE s.session_id=r.session_id AND s.session_id=a.session_id AND a.status='P' AND s.session_name=?");

            pstmt.setString(1, session_name);

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                rollno[i] = rs.getString("studentroll");
                regid[i] = rs.getString("regid");
                name[i] = rs.getString("name");
                email[i] = rs.getString("email");
                phno[i] = rs.getString("phno");
                year[i] = rs.getString("year");
                branch[i] = rs.getString("branch");
                i++;
            }

            rs.close();
            pstmt.close();
            con.close();
        } catch (SQLException e) {
            out.println("<html><body><h1>Error: " + e.getMessage() + "</h1></body></html>");
            return;
        }


        
	    // Generate the HTML response using the data from the arrays
	    out.println("<html>");
	    out.println("<head>");
	    out.println("<title>Number of Students " + session_name + "</title>");
        out.println("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css\">");

	    out.println("<style>");
	    out.println("table, th, td { border: 1px solid black; border-collapse: collapse; padding: 5px; }");
	    out.println("  body {");
        out.println("    padding: 0px;");
        out.println("    margin: 0;");
        out.println("    min-height: 100vh;");
        out.println("    background: url('background_cleanup.jpg')no-repeat;");
        out.println("    background-position: center;");
        out.println("    background-size: cover;");
        out.println("    background-color: transparent;");
        out.println("    backdrop-filter: blur(15px);");
        out.println("  }");
        out.println("  table {");
        out.println("    width: 100%;");
        out.println("    max-width: 100%;");
        out.println("    font-size: medium;");
        out.println("    font-family:sans-serif");

        out.println("    font-weight: 100;");
        out.println("  }");
        out.println("  table th, table td {");
        out.println("    border: 1px solid white;");
        out.println("    padding: 10px;");
        out.println("    color: white;");
        out.println("  }");
        out.println("  table th {");
        out.println("    font-weight: bold;");
        out.println("    color: rgb(197, 157, 14);");
        out.println("  }");
        out.println("</style>");
	    out.println("</style>");
	    out.println("</head>");
	    out.println("<body>");
	    out.println("<h1 style='color:white; font-weight:bold'>List Of Students Present for Session:" + session_name + "</h1>");

	    out.println("<table>");
	    out.println("<tr><th>Roll Number</th><th>Registration ID</th><th>Name</th><th>Email</th><th>Phone Number</th><th>Year</th><th>Branch</th></tr>");
	    for (int j = 0; j < i; j++) {
	      out.println("<tr>");
	      out.println("<td>" + rollno[j] + "</td>");
	      out.println("<td>" + regid[j] + "</td>");
	      out.println("<td>" + name[j] + "</td>");

	      out.println("<td>" + email[j] + "</td>");
	      out.println("<td>" + phno[j] + "</td>");
	      out.println("<td>" + year[j] + "</td>");
	      out.println("<td>" + branch[j] + "</td>");
	    
	    

	      out.println("</tr>");
	    }
	    out.println("</table>");
	    out.println("</body>");
	    out.println("</html>");
}
}








