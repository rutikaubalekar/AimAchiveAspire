import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/sessionservlet")
public class sessionservlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get the session type from the request parameter
        String sessiontype = request.getParameter("sessiontype");

        // Define arrays to store the data from the database
        String[] sessionIds = new String[50];
        String[] sessionTypes = new String[50];
        String[] name = new String[50];
        String[] dates = new String[50];
        String[] venue = new String[50];
        String[] time = new String[50];
        String[] lname = new String[50];
        String[] vname = new String[50];
        String[] role = new String[50];

        int i = 0;

        try {
            // Get a connection to the database
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root", "MansiItaly@123");

            // Prepare a statement to query the database
            PreparedStatement pstmt = con.prepareStatement("SELECT s.session_id, s.sessiontype, s.session_name, s.date, s.venue, s.time, l.Name, v.Vname, v.Role  FROM Session s, Volunteer v, Lecturer l WHERE s.session_id = v.session_id AND s.session_id = l.session_id AND s.sessiontype = ?");

            // Set the parameter value
            pstmt.setString(1, sessiontype);

            // Execute the query
            ResultSet rs = pstmt.executeQuery();

            // Loop through the result set and store data in arrays
            while (rs.next()) {
                sessionIds[i] = rs.getString("session_id");
                sessionTypes[i] = rs.getString("sessiontype");
                name[i] = rs.getString("session_name");
                dates[i] = rs.getString("date");
                venue[i] = rs.getString("venue");
                time[i] = rs.getString("time");
                lname[i] = rs.getString("Name");
                vname[i] = rs.getString("Vname");
                role[i] = rs.getString("Role");

                i++;
            }

            // Clean up resources
            rs.close();
            pstmt.close();
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
	    // Generate the HTML response using the data from the arrays
	    out.println("<html>");
	    out.println("<head>");
	    out.println("<title>Data for Session Type " + sessiontype + "</title>");
        out.println("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css\">");

	    out.println("<style>");
	    out.println("table, th, td { border: 1px solid black; border-collapse: collapse; padding: 5px; }");
	    out.println("  body {");
        out.println("    padding: 0px;");
        out.println("    margin: 0;");
        out.println("    min-height: 100vh;");
        out.println("    background: url('background_cleanup.jpg')no-repeat;");
        out.println("    background-position: center;");
        out.println("    background-size: cover;");
        out.println("    background-color: transparent;");
        out.println("    backdrop-filter: blur(15px);");
        out.println("  }");
        out.println("  table {");
        out.println("    width: 100%;");
        out.println("    max-width: 100%;");
        out.println("    font-size: medium;");
        out.println("    font-family:sans-serif");

        out.println("    font-weight: 100;");
        out.println("  }");
        out.println("  table th, table td {");
        out.println("    border: 1px solid white;");
        out.println("    padding: 10px;");
        out.println("    color: white;");
        out.println("  }");
        out.println("  table th {");
        out.println("    font-weight: bold;");
        out.println("    color: rgb(197, 157, 14);");
        out.println("  }");
        out.println("</style>");
	    out.println("</style>");
	    out.println("</head>");
	    out.println("<body>");
	    out.println("<h1 style='color:white; font-weight:bold'>Data for Session Type " + sessiontype + "</h1>");

	    out.println("<table>");
	    out.println("<tr><th>Session Id</th><th>Session Type</th><th>Session Name</th><th>Session Date</th><th>Venue</th><th>Time</th><th>Speaker Name</th><th>Volunteer Name</th><th>Role of Volunteer</th></tr>");
	    for (int j = 0; j < i; j++) {
	      out.println("<tr>");
	      out.println("<td>" + sessionIds[j] + "</td>");
	      out.println("<td>" + sessionTypes[j] + "</td>");
	      out.println("<td>" + name[j] + "</td>");

	      out.println("<td>" + dates[j] + "</td>");
	      out.println("<td>" + venue[j] + "</td>");
	      out.println("<td>" + time[j] + "</td>");
	      out.println("<td>" + lname[j] + "</td>");
	      out.println("<td>" + vname[j] + "</td>");
	      out.println("<td>" + role[j] + "</td>");
	    

	      out.println("</tr>");
	    }
	    out.println("</table>");
	    out.println("</body>");
	    out.println("</html>");
}
}
